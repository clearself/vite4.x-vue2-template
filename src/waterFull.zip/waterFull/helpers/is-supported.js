export const isSupported = () => !!window.Promise;
